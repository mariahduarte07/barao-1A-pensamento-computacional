# barao-1A-pensamento-computacional
## projeto de um site HTML e CSS

### colegio estadual barao do rio branco
disciplina de **pensamento computacional**

...

desenvolvimento de um site nas linguagens MTML e CSS

estudante: *mariah anne pavan duarte* n ´29´


estudante: *brenda heloisa santos da paixao* n ´5´
